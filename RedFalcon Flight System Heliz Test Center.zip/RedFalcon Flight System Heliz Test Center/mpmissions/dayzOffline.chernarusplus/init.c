void main()
{
	//INIT ECONOMY--------------------------------------
	Hive ce = CreateHive();
	if ( ce )
		ce.InitOffline();

	//DATE RESET AFTER ECONOMY INIT-------------------------
	int year, month, day, hour, minute;
	int reset_month = 9, reset_day = 20;
	GetGame().GetWorld().GetDate(year, month, day, hour, minute);

	if ((month == reset_month) && (day < reset_day))
	{
		GetGame().GetWorld().SetDate(year, reset_month, reset_day, hour, minute);
	}
	else
	{
		if ((month == reset_month + 1) && (day > reset_day))
		{
			GetGame().GetWorld().SetDate(year, reset_month, reset_day, hour, minute);
		}
		else
		{
			if ((month < reset_month) || (month > reset_month + 1))
			{
				GetGame().GetWorld().SetDate(year, reset_month, reset_day, hour, minute);
			}
		}
	}
}

class CustomMission: MissionServer
{
	void SetRandomHealth(EntityAI itemEnt)
	{
		if ( itemEnt )
		{
			float rndHlt = Math.RandomFloat( 0.9, 0.99 );
			itemEnt.SetHealth01( "", "", 100 );
		}
	}

	override PlayerBase CreateCharacter(PlayerIdentity identity, vector pos, ParamsReadContext ctx, string characterName)
	{
		Entity playerEnt;
		playerEnt = GetGame().CreatePlayer( identity, characterName, pos, 0, "NONE" );
		Class.CastTo( m_player, playerEnt );

		GetGame().SelectPlayer( identity, m_player );
		return m_player;
	}

	override void StartingEquipSetup(PlayerBase player, bool clothesChosen)
	{
		EntityAI itemTop;
		EntityAI itemEnt;
		ItemBase itemBs;
		float rand;

        player.GetStatEnergy().Set(7500);
        player.GetStatWater().Set(5000);

		itemTop = player.FindAttachmentBySlotName("Body");

		if ( itemTop )
		{
            player.RemoveAllItems();
            
            itemEnt = player.GetInventory().CreateInInventory("RFFSHeli_hoodie");
            itemEnt = player.GetInventory().CreateInInventory("HunterPants_Brown");
            itemEnt = player.GetInventory().CreateInInventory("HikingBootsLow_Black"); 
            itemEnt = player.GetInventory().CreateInInventory("Battery9v");
			itemEnt = player.GetInventory().CreateInInventory("NVGHeadstrap");
			itemEnt = player.GetInventory().CreateInInventory("NVGoggles");
			itemEnt = player.GetInventory().CreateInInventory("TacticalBaconCan");
            itemEnt = player.GetInventory().CreateInInventory("BandageDressing");
			itemEnt = player.GetInventory().CreateInInventory("CanOpener");
			itemEnt = player.GetInventory().CreateInInventory("CombatKnife");
            if ( Class.CastTo(itemBs, itemEnt ) )
                itemBs.SetQuantity(6); 
		}
	}
};

Mission CreateCustomMission(string path)
{
	return new CustomMission();
}